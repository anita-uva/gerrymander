Constituency-Level Elections Archive (CLEA)
GEOREFERENCED ELECTORAL DISTRICTS DATASETS (20181119)
Website: http://www.electiondataarchive.org
Email:   clea-project@umich.edu


Datasets and codebook are organized in individual folders by country name (e.g., Afghanistan). Each folder contains:

*readme_GRED_20190215.txt 	- This file

*GRED_20190215_codebook.pdf	- The codebook and supporting documentation explaining the variables, map sources, and protocols for map production.

*shapefiles			- Folder containing ESRI Shapefile (*.shp) file format


The files were created with ArcGIS 10.6.1, QGIS 2.18.4, OpenOffice 4.0.1, and R 3.5.1. 

